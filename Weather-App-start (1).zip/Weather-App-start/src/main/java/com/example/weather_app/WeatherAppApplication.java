package com.example.weather_app;

public class WeatherAppApplication {
	public static void main(String[] args) {

	}
}
